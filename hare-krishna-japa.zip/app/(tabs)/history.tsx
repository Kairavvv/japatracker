import { useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { BEADS, dayKey, fmt, useJapa } from '../../lib/store';
import { C } from '../../lib/theme';

export default function History() {
  const { days, today, settings } = useJapa();
  const [m, setM] = useState(() => { const d = new Date(); return new Date(d.getFullYear(), d.getMonth(), 1); });
  const y = m.getFullYear(), mo = m.getMonth(), n = new Date(y, mo + 1, 0).getDate();
  const key = (d: number) => dayKey(new Date(y, mo, d));
  const met = (t: number, target?: number) => t >= (target ?? settings.target) * BEADS;
  const cells = [...Array(m.getDay()).fill(0), ...Array.from({ length: n }, (_, i) => i + 1)] as number[];
  let tot = 0, hit = 0;
  for (let d = 1; d <= n; d++) { const r = days[key(d)]; if (r) { tot += r.total; if (met(r.total, r.target)) hit++; } }
  const all = Object.values(days).reduce((a, r) => a + r.total, 0);
  const go = (k: number) => setM(new Date(y, mo + k, 1));

  return (
    <SafeAreaView style={s.root}>
      <View style={s.nav}>
        <Pressable onPress={() => go(-1)} hitSlop={16}><Text style={s.arrow}>‹</Text></Pressable>
        <Text style={s.month}>{m.toLocaleDateString(undefined, { month: 'long', year: 'numeric' })}</Text>
        <Pressable onPress={() => go(1)} hitSlop={16}><Text style={s.arrow}>›</Text></Pressable>
      </View>
      <View style={s.grid}>
        {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((w, i) => <Text key={i} style={[s.cell, s.wk]}>{w}</Text>)}
        {cells.map((d, i) => {
          const r = d ? days[key(d)] : undefined, ok = !!r && met(r.total, r.target);
          return (
            <View key={i} style={s.cell}>
              {d ? (
                <View style={[s.day, key(d) === today && { backgroundColor: C.card }, ok && s.ok]}>
                  <Text style={[s.num, ok && { color: C.gold }]}>{d}</Text>
                  <Text style={s.sub}>{r && r.total ? fmt(r.total) : ' '}</Text>
                </View>
              ) : null}
            </View>
          );
        })}
      </View>
      <View style={s.card}>
        <Stat label="Rounds this month" value={fmt(tot)} />
        <Stat label="Days target met" value={String(hit)} />
        <Stat label="Total rounds, all time" value={fmt(all)} />
      </View>
    </SafeAreaView>
  );
}

const Stat = ({ label, value }: { label: string; value: string }) => (
  <View style={s.stat}><Text style={s.label}>{label}</Text><Text style={s.value}>{value}</Text></View>
);

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.bg, paddingHorizontal: 16 },
  nav: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 16, paddingHorizontal: 8 },
  month: { color: C.text, fontSize: 22, fontWeight: '600' },
  arrow: { color: C.saffron, fontSize: 34, paddingHorizontal: 8 },
  grid: { flexDirection: 'row', flexWrap: 'wrap' },
  cell: { width: '14.2857%', padding: 2, aspectRatio: 0.85 },
  wk: { color: C.mute, fontSize: 12, textAlign: 'center', aspectRatio: undefined, paddingVertical: 8 },
  day: { flex: 1, borderRadius: 12, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: 'transparent' },
  ok: { borderColor: C.gold, backgroundColor: 'rgba(201,162,77,0.10)' },
  num: { color: C.text, fontSize: 16 },
  sub: { color: C.mute, fontSize: 11, marginTop: 2 },
  card: { backgroundColor: C.card, borderRadius: 16, padding: 16, marginTop: 20 },
  stat: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 8 },
  label: { color: C.mute, fontSize: 15 },
  value: { color: C.text, fontSize: 15, fontWeight: '600' },
});
