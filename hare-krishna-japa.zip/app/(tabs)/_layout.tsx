import { Ionicons } from '@expo/vector-icons';
import { Tabs } from 'expo-router';
import { useJapa } from '../../lib/store';
import { C } from '../../lib/theme';

const icon = (name: keyof typeof Ionicons.glyphMap) => ({ color, size }: { color: string; size: number }) => <Ionicons name={name} size={size} color={color} />;

export default function TabsLayout() {
  const { loaded } = useJapa();
  if (!loaded) return null;
  return (
    <Tabs screenOptions={{ headerShown: false, tabBarActiveTintColor: C.saffron, tabBarInactiveTintColor: C.mute,
      tabBarStyle: { backgroundColor: C.bg, borderTopColor: C.line }, sceneStyle: { backgroundColor: C.bg } }}>
      <Tabs.Screen name="index" options={{ title: 'Home', tabBarIcon: icon('radio-button-on-outline') }} />
      <Tabs.Screen name="history" options={{ title: 'History', tabBarIcon: icon('calendar-outline') }} />
      <Tabs.Screen name="settings" options={{ title: 'Settings', tabBarIcon: icon('settings-outline') }} />
    </Tabs>
  );
}
