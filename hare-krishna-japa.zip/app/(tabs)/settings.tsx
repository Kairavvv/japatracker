import DateTimePicker from '@react-native-community/datetimepicker';
import React, { useState } from 'react';
import { Alert, Platform, Pressable, StyleSheet, Switch, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useJapa } from '../../lib/store';
import { C } from '../../lib/theme';

const Row = ({ label, children, onPress }: { label: string; children?: React.ReactNode; onPress?: () => void }) => (
  <Pressable onPress={onPress} disabled={!onPress} style={s.row}>{children === undefined ? <Text style={s.danger}>{label}</Text> : <><Text style={s.label}>{label}</Text>{children}</>}</Pressable>
);
const sw = (v: boolean, f: (b: boolean) => void) => <Switch value={v} onValueChange={f} trackColor={{ true: C.saffron, false: '#2A2A2E' }} />;
const confirm = (title: string, ok: string, fn: () => void) =>
  Alert.alert(title, undefined, [{ text: 'Cancel', style: 'cancel' }, { text: ok, style: 'destructive', onPress: fn }]);

export default function Settings() {
  const { settings: st, set, resetToday, eraseAll } = useJapa();
  const [show, setShow] = useState(Platform.OS === 'ios');
  const time = new Date(2000, 0, 1, st.hour, st.minute);
  const clamp = (n: number) => set({ target: Math.min(64, Math.max(1, n)) });

  return (
    <SafeAreaView style={s.root}>
      <Text style={s.title}>Settings</Text>
      <View style={s.card}>
        <Row label="Daily round target">
          <View style={s.step}>
            <Pressable onPress={() => clamp(st.target - 1)} hitSlop={12}><Text style={s.btn}>−</Text></Pressable>
            <Text style={s.val}>{st.target}</Text>
            <Pressable onPress={() => clamp(st.target + 1)} hitSlop={12}><Text style={s.btn}>+</Text></Pressable>
          </View>
        </Row>
        <Row label="Haptic feedback">{sw(st.haptics, (haptics) => set({ haptics }))}</Row>
        <Row label="Daily reminder">{sw(st.reminder, (reminder) => set({ reminder }))}</Row>
        {st.reminder && (
          <Row label="Reminder time" onPress={() => setShow(true)}>
            {show ? (
              <DateTimePicker mode="time" value={time} themeVariant="dark" display="compact"
                onChange={(_, d) => { if (Platform.OS !== 'ios') setShow(false); if (d) set({ hour: d.getHours(), minute: d.getMinutes() }); }} />
            ) : <Text style={s.val}>{String(st.hour).padStart(2, '0')}:{String(st.minute).padStart(2, '0')}</Text>}
          </Row>
        )}
      </View>
      <View style={s.card}>
        <Row label="Reset today's progress" onPress={() => confirm("Reset today's progress?", 'Reset', resetToday)} />
        <Row label="Erase all history" onPress={() => confirm('Erase all history? This cannot be undone.', 'Erase', eraseAll)} />
      </View>
      <Text style={s.foot}>All data stays on this device.</Text>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.bg, paddingHorizontal: 16 },
  title: { color: C.text, fontSize: 32, fontWeight: '600', marginVertical: 16, paddingHorizontal: 4 },
  card: { backgroundColor: C.card, borderRadius: 16, paddingHorizontal: 16, marginBottom: 20 },
  row: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', minHeight: 54 },
  label: { color: C.text, fontSize: 16 },
  danger: { color: '#E5675B', fontSize: 16 },
  step: { flexDirection: 'row', alignItems: 'center' },
  btn: { color: C.saffron, fontSize: 28, paddingHorizontal: 14 },
  val: { color: C.text, fontSize: 17, minWidth: 28, textAlign: 'center' },
  foot: { color: C.mute, fontSize: 13, textAlign: 'center' },
});
