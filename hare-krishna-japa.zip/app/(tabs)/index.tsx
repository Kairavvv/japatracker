import * as Haptics from 'expo-haptics';
import { useEffect, useRef, useState } from 'react';
import { Animated, Pressable, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Svg, { Circle } from 'react-native-svg';
import { BEADS, useJapa } from '../../lib/store';
import { C } from '../../lib/theme';

const AC = Animated.createAnimatedComponent(Circle);
const SIZE = 250, SW = 8, R = (SIZE - SW) / 2, CIRC = 2 * Math.PI * R, MID = SIZE / 2;

export default function Home() {
  const { today, days, settings, add, undo } = useJapa();
  const [mode, setMode] = useState<'round' | 'bead'>('round'); // always starts in Round mode
  const total = days[today]?.total ?? 0;
  const goal = settings.target * BEADS;
  const rounds = Math.floor(total / BEADS);
  const left = Math.max(0, settings.target - rounds);
  const done = total >= goal;
  const prog = useRef(new Animated.Value(0)).current;
  const last = useRef(0);
  const date = new Date(today + 'T12:00:00').toLocaleDateString(undefined, { weekday: 'long', day: 'numeric', month: 'long' });

  useEffect(() => {
    Animated.timing(prog, { toValue: Math.min(1, total / goal), duration: 350, useNativeDriver: false }).start();
  }, [total, goal, prog]);

  const tap = () => {
    const t = Date.now();
    if (t - last.current < 70) return; // guards against double-fires, imperceptible to a human
    last.current = t;
    const n = mode === 'round' ? BEADS : 1, next = total + n;
    if (settings.haptics) {
      if (total < goal && next >= goal) Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      else if (Math.floor(next / BEADS) > rounds) Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
      else Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    add(n);
  };

  return (
    <SafeAreaView style={s.root}>
      <View style={s.head}>
        <Text style={s.title}>Hare Kṛṣṇa</Text>
        <Text style={s.date}>{date}</Text>
      </View>

      <View style={s.ring}>
        <Svg width={SIZE} height={SIZE}>
          <Circle cx={MID} cy={MID} r={R} stroke={C.line} strokeWidth={SW} fill="none" />
          <AC cx={MID} cy={MID} r={R} stroke={done ? C.gold : C.saffron} strokeWidth={SW} strokeLinecap="round" fill="none"
            opacity={total ? 1 : 0} strokeDasharray={CIRC} rotation="-90" origin={`${MID}, ${MID}`}
            strokeDashoffset={prog.interpolate({ inputRange: [0, 1], outputRange: [CIRC, 0] })} />
        </Svg>
        <View style={s.center}>
          <Text style={s.big}>{rounds}<Text style={s.goal}> / {settings.target}</Text></Text>
          <Text style={s.cap}>ROUNDS COMPLETED</Text>
        </View>
      </View>
      <Text style={[s.left, done && { color: C.gold }]}>
        {done ? 'Daily target complete ✓' : `${left} round${left === 1 ? '' : 's'} remaining`}
      </Text>

      <View style={s.bottom}>
        <View style={s.seg}>
          {(['round', 'bead'] as const).map((m) => (
            <Pressable key={m} onPress={() => setMode(m)} style={[s.segItem, mode === m && s.segOn]}>
              <Text style={[s.segTxt, mode === m && { color: C.text }]}>{m === 'round' ? 'Round Counter' : 'Bead Counter'}</Text>
            </Pressable>
          ))}
        </View>
        <Text style={s.bead}>{mode === 'bead' ? `${total % BEADS} / ${BEADS}` : ' '}</Text>
        <Pressable onPressIn={tap} style={({ pressed }) => [s.btn, pressed && { transform: [{ scale: 0.97 }], opacity: 0.9 }]}>
          <Text style={s.btnTxt}>{mode === 'round' ? '+1 Round' : '+1 Maha-mantra'}</Text>
        </Pressable>
        <Pressable onPress={undo} disabled={!total} hitSlop={16} style={{ opacity: total ? 1 : 0.3 }}>
          <Text style={s.undo}>Undo</Text>
        </Pressable>
      </View>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.bg, alignItems: 'center', paddingHorizontal: 24 },
  head: { alignItems: 'center', marginTop: 12 },
  title: { color: C.text, fontSize: 32, fontWeight: '600', letterSpacing: 0.3 },
  date: { color: C.mute, fontSize: 15, marginTop: 4 },
  ring: { marginTop: 28, alignItems: 'center', justifyContent: 'center' },
  center: { position: 'absolute', alignItems: 'center' },
  big: { color: C.text, fontSize: 60, fontWeight: '200' },
  goal: { color: C.mute, fontSize: 30 },
  cap: { color: C.mute, fontSize: 11, letterSpacing: 2.5, marginTop: 4 },
  left: { color: C.mute, fontSize: 16, marginTop: 20 },
  bottom: { flex: 1, width: '100%', justifyContent: 'flex-end', alignItems: 'center', paddingBottom: 16 },
  seg: { flexDirection: 'row', backgroundColor: C.card, borderRadius: 12, padding: 3 },
  segItem: { paddingVertical: 8, paddingHorizontal: 16, borderRadius: 10 },
  segOn: { backgroundColor: '#2A2A2E' },
  segTxt: { color: C.mute, fontSize: 14, fontWeight: '500' },
  bead: { color: C.gold, fontSize: 22, fontWeight: '300', marginVertical: 14, height: 28 },
  btn: { width: '100%', height: 92, borderRadius: 46, backgroundColor: C.saffron, alignItems: 'center', justifyContent: 'center' },
  btnTxt: { color: '#1A1208', fontSize: 22, fontWeight: '600' },
  undo: { color: C.mute, fontSize: 16, marginTop: 18 },
});
