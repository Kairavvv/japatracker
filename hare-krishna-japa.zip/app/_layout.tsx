import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { JapaProvider } from '../lib/store';
import { C } from '../lib/theme';

export default function Root() {
  return (
    <JapaProvider>
      <StatusBar style="light" />
      <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: C.bg } }} />
    </JapaProvider>
  );
}
