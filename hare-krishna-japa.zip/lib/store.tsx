import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Notifications from 'expo-notifications';
import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { AppState } from 'react-native';

export const BEADS = 108; // maha-mantras per round
export type Day = { total: number; log: number[]; target: number };
export type Settings = { target: number; haptics: boolean; reminder: boolean; hour: number; minute: number };
type Data = { days: Record<string, Day>; settings: Settings };
type Ctx = {
  loaded: boolean; today: string; days: Record<string, Day>; settings: Settings;
  add: (n: number) => void; undo: () => void; resetToday: () => void; eraseAll: () => void; set: (p: Partial<Settings>) => void;
};

const KEY = 'japa.v1';
const DEFAULTS: Settings = { target: 16, haptics: true, reminder: false, hour: 5, minute: 0 };
export const dayKey = (d = new Date()) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
export const fmt = (total: number) => { const r = total / BEADS; return Number.isInteger(r) ? String(r) : r.toFixed(1); };

const Context = createContext<Ctx>(null as unknown as Ctx);
export const useJapa = () => useContext(Context);

export function JapaProvider({ children }: { children: React.ReactNode }) {
  const [data, setData] = useState<Data>({ days: {}, settings: DEFAULTS });
  const [loaded, setLoaded] = useState(false);
  const [today, setToday] = useState(dayKey());
  const ref = useRef(data);

  const commit = useCallback((next: Data) => {
    ref.current = next; setData(next);
    AsyncStorage.setItem(KEY, JSON.stringify(next)).catch(() => {}); // saved on every change
  }, []);

  useEffect(() => {
    AsyncStorage.getItem(KEY).then((s) => {
      if (s) { const p = JSON.parse(s); commit({ days: p.days ?? {}, settings: { ...DEFAULTS, ...p.settings } }); }
    }).catch(() => {}).finally(() => setLoaded(true));
  }, [commit]);

  // Midnight rollover in device-local time
  useEffect(() => {
    const tick = () => setToday(dayKey());
    const i = setInterval(tick, 10000);
    const sub = AppState.addEventListener('change', tick);
    return () => { clearInterval(i); sub.remove(); };
  }, []);

  const add = (n: number) => {
    const k = dayKey(), c = ref.current, d = c.days[k] ?? { total: 0, log: [], target: c.settings.target };
    setToday(k);
    commit({ ...c, days: { ...c.days, [k]: { total: d.total + n, log: [...d.log, n], target: c.settings.target } } });
  };
  const undo = () => {
    const k = dayKey(), c = ref.current, d = c.days[k];
    if (!d || !d.log.length) return;
    commit({ ...c, days: { ...c.days, [k]: { ...d, total: d.total - d.log[d.log.length - 1], log: d.log.slice(0, -1) } } });
  };
  const resetToday = () => { const c = ref.current, days = { ...c.days }; delete days[dayKey()]; commit({ ...c, days }); };
  const eraseAll = () => commit({ ...ref.current, days: {} });
  const set = (p: Partial<Settings>) => commit({ ...ref.current, settings: { ...ref.current.settings, ...p } });

  const s = data.settings;
  useEffect(() => {
    if (!loaded) return;
    (async () => {
      await Notifications.cancelAllScheduledNotificationsAsync();
      if (!s.reminder) return;
      if (!(await Notifications.requestPermissionsAsync()).granted) return;
      await Notifications.scheduleNotificationAsync({
        content: { title: 'Hare Kṛṣṇa', body: 'Time for your japa.' },
        trigger: { type: Notifications.SchedulableTriggerInputTypes.DAILY, hour: s.hour, minute: s.minute },
      });
    })().catch(() => {});
  }, [loaded, s.reminder, s.hour, s.minute]);

  return <Context.Provider value={{ loaded, today, days: data.days, settings: s, add, undo, resetToday, eraseAll, set }}>{children}</Context.Provider>;
}
