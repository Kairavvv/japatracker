export const C = { bg: '#0B0B0C', card: '#161618', line: '#262629', text: '#F4F1EA', mute: '#8A8A90', saffron: '#E8892B', gold: '#C9A24D' };
