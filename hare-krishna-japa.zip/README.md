# Hare Kṛṣṇa – japa counter
1. `npx create-expo-app@latest hare-krishna --template blank-typescript && cd hare-krishna`
2. `npx expo install expo-router expo-linking expo-constants expo-status-bar expo-haptics expo-notifications react-native-svg react-native-safe-area-context react-native-screens @react-native-async-storage/async-storage @react-native-community/datetimepicker @expo/vector-icons`
3. Copy `app/`, `lib/`, `app.json` from this zip into the project (replace app.json). Delete `App.tsx` and `index.ts`. In package.json set `"main": "expo-router/entry"`.
4. `npx expo start`
